from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from drf_spectacular.views import SpectacularAPIView, SpectacularSwaggerUIView

urlpatterns = [
    path("admin/", admin.site.urls),

    # API v1
    path("api/auth/",    include("apps.accounts.urls")),
    path("api/forms/",   include("apps.forms_builder.urls")),
    path("api/submissions/", include("apps.submissions.urls")),
    path("api/canvas/",  include("apps.canvas_integration.urls")),

    # Public form access (no auth required)
    path("f/", include("apps.forms_builder.public_urls")),

    # API schema / docs
    path("api/schema/",  SpectacularAPIView.as_view(), name="schema"),
    path("api/docs/",    SpectacularSwaggerUIView.as_view(url_name="schema"), name="swagger-ui"),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
