from rest_framework import serializers
from .models import User


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = [
            "id", "username", "email", "first_name", "last_name",
            "role", "canvas_user_id", "avatar_url", "is_canvas_user",
            "is_active", "created_at",
        ]
        read_only_fields = ["id", "canvas_user_id", "is_canvas_user", "created_at"]


class UserCreateSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, min_length=8)

    class Meta:
        model = User
        fields = ["username", "email", "first_name", "last_name", "role", "password"]

    def create(self, validated_data):
        password = validated_data.pop("password")
        user = User(**validated_data)
        user.set_password(password)
        user.save()
        return user


class CanvasLoginSerializer(serializers.Serializer):
    """Used to initiate Canvas OAuth — just returns the redirect URL."""
    redirect_url = serializers.URLField(read_only=True)


class MeSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = [
            "id", "username", "email", "first_name", "last_name",
            "role", "canvas_user_id", "avatar_url", "is_canvas_user",
        ]
