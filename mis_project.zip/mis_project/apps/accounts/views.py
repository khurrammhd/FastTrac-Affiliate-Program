import requests
from django.conf import settings
from django.utils import timezone
from datetime import timedelta

from rest_framework import generics, status, permissions
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.tokens import RefreshToken

from .models import User, CanvasOAuthToken
from .serializers import UserSerializer, UserCreateSerializer, MeSerializer


def get_tokens_for_user(user):
    refresh = RefreshToken.for_user(user)
    return {
        "refresh": str(refresh),
        "access": str(refresh.access_token),
    }


class MeView(APIView):
    """Returns the currently authenticated user's profile."""
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        serializer = MeSerializer(request.user)
        return Response(serializer.data)

    def patch(self, request):
        serializer = MeSerializer(request.user, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)


class UserListCreateView(generics.ListCreateAPIView):
    """List all users (admin only) or create a new local user."""
    queryset = User.objects.all()
    permission_classes = [permissions.IsAuthenticated]

    def get_serializer_class(self):
        if self.request.method == "POST":
            return UserCreateSerializer
        return UserSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        if not self.request.user.is_admin_or_above:
            qs = qs.filter(pk=self.request.user.pk)
        return qs


class UserDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [permissions.IsAuthenticated]


# ── Canvas OAuth 2.0 ───────────────────────────────────────────────────────

class CanvasOAuthInitView(APIView):
    """
    Step 1: Return the Canvas OAuth authorization URL.
    Frontend redirects the user to this URL.
    """
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        params = (
            f"client_id={settings.CANVAS_CLIENT_ID}"
            f"&response_type=code"
            f"&redirect_uri={settings.CANVAS_REDIRECT_URI}"
            f"&scope=url:GET|/api/v1/users/:id"
        )
        auth_url = f"{settings.CANVAS_BASE_URL}/login/oauth2/auth?{params}"
        return Response({"auth_url": auth_url})


class CanvasOAuthCallbackView(APIView):
    """
    Step 2: Canvas redirects back here with ?code=...
    Exchange the code for a token, fetch the Canvas user profile,
    create/update the local User, and return a JWT pair.
    """
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        code = request.query_params.get("code")
        if not code:
            return Response({"error": "Missing authorization code."}, status=400)

        # Exchange code for token
        token_resp = requests.post(
            f"{settings.CANVAS_BASE_URL}/login/oauth2/token",
            data={
                "grant_type": "authorization_code",
                "client_id": settings.CANVAS_CLIENT_ID,
                "client_secret": settings.CANVAS_CLIENT_SECRET,
                "redirect_uri": settings.CANVAS_REDIRECT_URI,
                "code": code,
            },
            timeout=10,
        )

        if token_resp.status_code != 200:
            return Response({"error": "Failed to obtain Canvas token."}, status=400)

        token_data = token_resp.json()
        access_token = token_data.get("access_token")

        # Fetch Canvas user profile
        profile_resp = requests.get(
            f"{settings.CANVAS_BASE_URL}/api/v1/users/self/profile",
            headers={"Authorization": f"Bearer {access_token}"},
            timeout=10,
        )

        if profile_resp.status_code != 200:
            return Response({"error": "Failed to fetch Canvas profile."}, status=400)

        profile = profile_resp.json()
        canvas_user_id = str(profile.get("id"))
        login_id = profile.get("login_id", "")
        name_parts = profile.get("name", "").split(" ", 1)

        # Get or create the local user
        user, _ = User.objects.get_or_create(
            canvas_user_id=canvas_user_id,
            defaults={
                "username": login_id or f"canvas_{canvas_user_id}",
                "email": profile.get("primary_email", ""),
                "first_name": name_parts[0] if name_parts else "",
                "last_name": name_parts[1] if len(name_parts) > 1 else "",
                "role": User.Role.ADMIN,
                "is_canvas_user": True,
                "canvas_login_id": login_id,
                "avatar_url": profile.get("avatar_url"),
            },
        )

        # Upsert token
        expires_at = None
        if token_data.get("expires_in"):
            expires_at = timezone.now() + timedelta(seconds=token_data["expires_in"])

        CanvasOAuthToken.objects.update_or_create(
            user=user,
            defaults={
                "access_token": access_token,
                "refresh_token": token_data.get("refresh_token", ""),
                "token_type": token_data.get("token_type", "Bearer"),
                "expires_at": expires_at,
                "canvas_user_id": canvas_user_id,
            },
        )

        return Response({
            "user": MeSerializer(user).data,
            "tokens": get_tokens_for_user(user),
        })
