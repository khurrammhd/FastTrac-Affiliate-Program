from django.urls import path
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from .views import (
    MeView,
    UserListCreateView,
    UserDetailView,
    CanvasOAuthInitView,
    CanvasOAuthCallbackView,
)

urlpatterns = [
    # Local JWT auth
    path("login/",          TokenObtainPairView.as_view(),  name="token_obtain"),
    path("token/refresh/",  TokenRefreshView.as_view(),     name="token_refresh"),

    # Logged-in user
    path("me/",             MeView.as_view(),               name="me"),

    # User management
    path("users/",          UserListCreateView.as_view(),   name="user_list"),
    path("users/<int:pk>/", UserDetailView.as_view(),       name="user_detail"),

    # Canvas OAuth 2.0
    path("canvas/",          CanvasOAuthInitView.as_view(),     name="canvas_oauth_init"),
    path("canvas/callback/", CanvasOAuthCallbackView.as_view(), name="canvas_oauth_callback"),
]
