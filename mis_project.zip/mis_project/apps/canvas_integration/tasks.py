import logging
from celery import shared_task
from django.utils import timezone

logger = logging.getLogger(__name__)


@shared_task(bind=True, max_retries=3, default_retry_delay=60)
def sync_submission_to_canvas(self, submission_id):
    """
    Triggered after an admin approves a submission.

    Steps:
      1. Extract name / email from submission data using field canvas_field_mapping.
      2. Create the user in Canvas.
      3. If the form has a canvas_course_id, enroll the user.
      4. Mark submission as SYNCED or FAILED.
    """
    from apps.submissions.models import Submission
    from .client import CanvasAPIClient

    try:
        submission = Submission.objects.select_related("form").get(pk=submission_id)
    except Submission.DoesNotExist:
        logger.error("sync_submission_to_canvas: Submission %s not found.", submission_id)
        return

    if submission.status == Submission.Status.SYNCED:
        logger.info("Submission %s already synced, skipping.", submission_id)
        return

    client = CanvasAPIClient()

    # Build user attributes from mapped fields
    name = submission.submitter_name or _extract_field(submission, "name") or "Unknown"
    email = submission.submitter_email or _extract_field(submission, "email")

    if not email:
        _fail(submission, "Could not determine email from submission data.")
        return

    try:
        canvas_user = client.create_user(name=name, email=email)
        canvas_user_id = str(canvas_user.get("id", ""))

        submission.canvas_user_id = canvas_user_id

        # Enroll if form is linked to a course
        course_id = submission.form.canvas_course_id
        if course_id and canvas_user_id:
            enrollment = client.enroll_user(course_id, canvas_user_id)
            submission.canvas_enrollment_id = str(enrollment.get("id", ""))

        submission.status = Submission.Status.SYNCED
        submission.canvas_synced_at = timezone.now()
        submission.canvas_sync_error = ""
        submission.save()

        logger.info("Submission %s synced to Canvas. Canvas user ID: %s", submission_id, canvas_user_id)

    except Exception as exc:
        logger.exception("Canvas sync failed for submission %s: %s", submission_id, exc)
        try:
            raise self.retry(exc=exc)
        except self.MaxRetriesExceededError:
            _fail(submission, str(exc))


def _extract_field(submission, mapping_key):
    """
    Looks through form fields for one mapped to `mapping_key`
    and returns its value from submission.data.
    """
    from apps.forms_builder.models import FormField
    field = FormField.objects.filter(
        form=submission.form,
        canvas_field_mapping=mapping_key,
    ).first()
    if field:
        return submission.data.get(str(field.pk), "")
    return ""


def _fail(submission, error_msg):
    from apps.submissions.models import Submission
    submission.status = Submission.Status.FAILED
    submission.canvas_sync_error = error_msg
    submission.save()
    logger.error("Submission %s marked FAILED: %s", submission.pk, error_msg)
