from django.utils import timezone
from rest_framework import generics, permissions, filters
from rest_framework.response import Response
from rest_framework.views import APIView
from django_filters.rest_framework import DjangoFilterBackend

from .models import Submission, SubmissionNote
from .serializers import (
    SubmissionSerializer,
    PublicSubmissionCreateSerializer,
    SubmissionNoteSerializer,
    SubmissionApproveSerializer,
    SubmissionRejectSerializer,
)
from apps.canvas_integration.tasks import sync_submission_to_canvas


class SubmissionListView(generics.ListAPIView):
    """Admin: list all submissions with filtering."""
    serializer_class = SubmissionSerializer
    permission_classes = [permissions.IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ["status", "form"]
    search_fields = ["submitter_email", "submitter_name"]
    ordering_fields = ["submitted_at", "updated_at"]

    def get_queryset(self):
        return Submission.objects.select_related("form", "reviewed_by").prefetch_related("notes")


class SubmissionDetailView(generics.RetrieveAPIView):
    queryset = Submission.objects.all()
    serializer_class = SubmissionSerializer
    permission_classes = [permissions.IsAuthenticated]


class SubmissionApproveView(APIView):
    """
    Admin approves a pending submission.
    Triggers async Canvas sync via Celery.
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, pk):
        try:
            submission = Submission.objects.get(pk=pk, status=Submission.Status.PENDING)
        except Submission.DoesNotExist:
            return Response({"error": "Submission not found or not pending."}, status=404)

        serializer = SubmissionApproveSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        submission.status = Submission.Status.APPROVED
        submission.reviewed_by = request.user
        submission.reviewed_at = timezone.now()
        submission.save()

        # Add optional review note
        note_body = serializer.validated_data.get("note", "").strip()
        if note_body:
            SubmissionNote.objects.create(
                submission=submission,
                author=request.user,
                body=note_body,
            )

        # Kick off async Canvas user creation
        sync_submission_to_canvas.delay(submission.pk)

        return Response(SubmissionSerializer(submission).data)


class SubmissionRejectView(APIView):
    """Admin rejects a pending submission."""
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, pk):
        try:
            submission = Submission.objects.get(pk=pk, status=Submission.Status.PENDING)
        except Submission.DoesNotExist:
            return Response({"error": "Submission not found or not pending."}, status=404)

        serializer = SubmissionRejectSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        submission.status = Submission.Status.REJECTED
        submission.reviewed_by = request.user
        submission.reviewed_at = timezone.now()
        submission.rejection_reason = serializer.validated_data["reason"]
        submission.save()

        return Response(SubmissionSerializer(submission).data)


class SubmissionNoteCreateView(generics.CreateAPIView):
    """Add an internal note to a submission."""
    serializer_class = SubmissionNoteSerializer
    permission_classes = [permissions.IsAuthenticated]

    def perform_create(self, serializer):
        submission = Submission.objects.get(pk=self.kwargs["pk"])
        serializer.save(author=self.request.user, submission=submission)


# ── Public endpoint (no auth) ──────────────────────────────────────────────

class PublicSubmissionCreateView(generics.CreateAPIView):
    """
    Anyone with a valid form token can POST a submission here.
    Auth is not required.
    """
    serializer_class = PublicSubmissionCreateSerializer
    permission_classes = [permissions.AllowAny]

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        submission = serializer.save()
        return Response(
            {"message": "Your submission has been received. You will be notified once it is reviewed."},
            status=201,
        )
