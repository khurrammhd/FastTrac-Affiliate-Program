from django.urls import path
from .views import (
    SubmissionListView,
    SubmissionDetailView,
    SubmissionApproveView,
    SubmissionRejectView,
    SubmissionNoteCreateView,
    PublicSubmissionCreateView,
)

urlpatterns = [
    # Admin
    path("",                        SubmissionListView.as_view(),       name="submission_list"),
    path("<int:pk>/",               SubmissionDetailView.as_view(),     name="submission_detail"),
    path("<int:pk>/approve/",       SubmissionApproveView.as_view(),    name="submission_approve"),
    path("<int:pk>/reject/",        SubmissionRejectView.as_view(),     name="submission_reject"),
    path("<int:pk>/notes/",         SubmissionNoteCreateView.as_view(), name="submission_note"),

    # Public
    path("submit/",                 PublicSubmissionCreateView.as_view(), name="public_submit"),
]
