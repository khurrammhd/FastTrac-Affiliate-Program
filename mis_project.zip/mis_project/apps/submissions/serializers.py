from rest_framework import serializers
from .models import Submission, SubmissionNote


class SubmissionNoteSerializer(serializers.ModelSerializer):
    author_name = serializers.SerializerMethodField()

    class Meta:
        model = SubmissionNote
        fields = ["id", "author", "author_name", "body", "created_at"]
        read_only_fields = ["id", "author", "created_at"]

    def get_author_name(self, obj):
        return obj.author.get_full_name() if obj.author else None


class SubmissionSerializer(serializers.ModelSerializer):
    notes = SubmissionNoteSerializer(many=True, read_only=True)
    reviewed_by_name = serializers.SerializerMethodField()
    form_title = serializers.SerializerMethodField()

    class Meta:
        model = Submission
        fields = [
            "id", "form", "form_title", "data", "status",
            "submitter_email", "submitter_name",
            "reviewed_by", "reviewed_by_name", "reviewed_at", "rejection_reason",
            "canvas_user_id", "canvas_enrollment_id", "canvas_sync_error", "canvas_synced_at",
            "submitted_at", "updated_at",
            "notes",
        ]
        read_only_fields = [
            "id", "status", "reviewed_by", "reviewed_at",
            "canvas_user_id", "canvas_enrollment_id", "canvas_sync_error",
            "canvas_synced_at", "submitted_at", "updated_at",
        ]

    def get_reviewed_by_name(self, obj):
        return obj.reviewed_by.get_full_name() if obj.reviewed_by else None

    def get_form_title(self, obj):
        return obj.form.title


class PublicSubmissionCreateSerializer(serializers.ModelSerializer):
    """Used by anonymous public users to submit a form."""

    class Meta:
        model = Submission
        fields = ["form", "data", "submitter_email", "submitter_name"]

    def validate(self, attrs):
        form = attrs.get("form")
        if form.status != "published":
            raise serializers.ValidationError("This form is not accepting submissions.")
        return attrs


class SubmissionApproveSerializer(serializers.Serializer):
    """Payload for approving a submission."""
    note = serializers.CharField(required=False, allow_blank=True)


class SubmissionRejectSerializer(serializers.Serializer):
    """Payload for rejecting a submission."""
    reason = serializers.CharField(required=True)
