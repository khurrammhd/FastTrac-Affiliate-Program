from django.utils import timezone
from rest_framework import generics, permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import Form, FormField
from .serializers import FormSerializer, FormWriteSerializer, FormFieldSerializer, PublicFormSerializer


class FormListCreateView(generics.ListCreateAPIView):
    queryset = Form.objects.all()
    permission_classes = [permissions.IsAuthenticated]

    def get_serializer_class(self):
        return FormWriteSerializer if self.request.method == "POST" else FormSerializer

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)


class FormDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Form.objects.all()
    permission_classes = [permissions.IsAuthenticated]

    def get_serializer_class(self):
        if self.request.method in ("PUT", "PATCH"):
            return FormWriteSerializer
        return FormSerializer


class FormPublishView(APIView):
    """Toggle a form to Published status."""
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, pk):
        try:
            form = Form.objects.get(pk=pk)
        except Form.DoesNotExist:
            return Response({"error": "Form not found."}, status=404)

        form.status = Form.Status.PUBLISHED
        form.published_at = timezone.now()
        form.save()
        return Response(FormSerializer(form).data)


class FormCloseView(APIView):
    """Close a form so it no longer accepts submissions."""
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, pk):
        try:
            form = Form.objects.get(pk=pk)
        except Form.DoesNotExist:
            return Response({"error": "Form not found."}, status=404)

        form.status = Form.Status.CLOSED
        form.save()
        return Response(FormSerializer(form).data)


class FormFieldListCreateView(generics.ListCreateAPIView):
    serializer_class = FormFieldSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return FormField.objects.filter(form_id=self.kwargs["form_pk"])

    def perform_create(self, serializer):
        form = Form.objects.get(pk=self.kwargs["form_pk"])
        serializer.save(form=form)


class FormFieldDetailView(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = FormFieldSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return FormField.objects.filter(form_id=self.kwargs["form_pk"])


# ── Public view (no auth) ──────────────────────────────────────────────────

class PublicFormView(APIView):
    """
    Public endpoint — returns a form by its public_token UUID.
    Only returns published, non-expired forms.
    """
    permission_classes = [permissions.AllowAny]

    def get(self, request, token):
        now = timezone.now()
        try:
            form = Form.objects.get(
                public_token=token,
                status=Form.Status.PUBLISHED,
            )
        except Form.DoesNotExist:
            return Response({"error": "Form not found or not available."}, status=404)

        if form.closes_at and now > form.closes_at:
            return Response({"error": "This form is closed."}, status=410)

        return Response(PublicFormSerializer(form).data)
