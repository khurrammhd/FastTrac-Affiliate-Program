import uuid
from django.db import models
from django.conf import settings


class Form(models.Model):
    """
    A form definition created by an admin.
    Each form gets a unique public slug for the public registration URL.
    """

    class Status(models.TextChoices):
        DRAFT = "draft", "Draft"
        PUBLISHED = "published", "Published"
        CLOSED = "closed", "Closed"

    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    slug = models.SlugField(unique=True, max_length=80)
    public_token = models.UUIDField(default=uuid.uuid4, unique=True, editable=False)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.DRAFT)

    # Optional: link form submissions to a Canvas course for auto-enroll
    canvas_course_id = models.CharField(max_length=64, blank=True, null=True)
    canvas_course_name = models.CharField(max_length=255, blank=True)

    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        related_name="forms_created",
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    published_at = models.DateTimeField(null=True, blank=True)
    closes_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.title} [{self.status}]"

    @property
    def public_url(self):
        return f"/f/{self.public_token}/"


class FormField(models.Model):
    """
    A single field within a Form. Fields are ordered by `order`.
    field_options stores choices for select/radio/checkbox as JSON list.
    """

    class FieldType(models.TextChoices):
        TEXT = "text", "Short text"
        TEXTAREA = "textarea", "Long text"
        EMAIL = "email", "Email"
        PHONE = "phone", "Phone number"
        NUMBER = "number", "Number"
        DATE = "date", "Date"
        SELECT = "select", "Dropdown"
        RADIO = "radio", "Radio buttons"
        CHECKBOX = "checkbox", "Checkboxes"
        FILE = "file", "File upload"

    form = models.ForeignKey(Form, on_delete=models.CASCADE, related_name="fields")
    label = models.CharField(max_length=255)
    field_type = models.CharField(max_length=20, choices=FieldType.choices)
    placeholder = models.CharField(max_length=255, blank=True)
    help_text = models.CharField(max_length=500, blank=True)
    is_required = models.BooleanField(default=False)
    order = models.PositiveIntegerField(default=0)

    # JSON list of strings for select/radio/checkbox
    field_options = models.JSONField(default=list, blank=True)

    # Maps this field to a Canvas user attribute (e.g. "name", "email")
    canvas_field_mapping = models.CharField(max_length=64, blank=True)

    class Meta:
        ordering = ["order"]

    def __str__(self):
        return f"{self.form.title} → {self.label} ({self.field_type})"
