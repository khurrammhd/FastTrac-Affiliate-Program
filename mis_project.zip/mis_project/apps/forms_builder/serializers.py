from rest_framework import serializers
from .models import Form, FormField


class FormFieldSerializer(serializers.ModelSerializer):
    class Meta:
        model = FormField
        fields = [
            "id", "label", "field_type", "placeholder", "help_text",
            "is_required", "order", "field_options", "canvas_field_mapping",
        ]


class FormSerializer(serializers.ModelSerializer):
    fields = FormFieldSerializer(many=True, read_only=True)
    created_by_name = serializers.SerializerMethodField()
    public_url = serializers.ReadOnlyField()

    class Meta:
        model = Form
        fields = [
            "id", "title", "description", "slug", "public_token",
            "status", "canvas_course_id", "canvas_course_name",
            "created_by", "created_by_name", "public_url",
            "created_at", "updated_at", "published_at", "closes_at",
            "fields",
        ]
        read_only_fields = ["id", "public_token", "created_by", "created_at", "updated_at"]

    def get_created_by_name(self, obj):
        return obj.created_by.get_full_name() if obj.created_by else None


class FormWriteSerializer(serializers.ModelSerializer):
    """Used for create/update — accepts nested fields."""
    fields = FormFieldSerializer(many=True, required=False)

    class Meta:
        model = Form
        fields = [
            "title", "description", "slug", "status",
            "canvas_course_id", "canvas_course_name",
            "published_at", "closes_at", "fields",
        ]

    def create(self, validated_data):
        fields_data = validated_data.pop("fields", [])
        form = Form.objects.create(**validated_data)
        for i, field_data in enumerate(fields_data):
            field_data.setdefault("order", i)
            FormField.objects.create(form=form, **field_data)
        return form

    def update(self, instance, validated_data):
        fields_data = validated_data.pop("fields", None)
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()

        if fields_data is not None:
            instance.fields.all().delete()
            for i, field_data in enumerate(fields_data):
                field_data.setdefault("order", i)
                FormField.objects.create(form=instance, **field_data)

        return instance


class PublicFormSerializer(serializers.ModelSerializer):
    """Minimal serializer for the public form view — no internal data."""
    fields = FormFieldSerializer(many=True, read_only=True)

    class Meta:
        model = Form
        fields = ["id", "title", "description", "fields", "closes_at"]
