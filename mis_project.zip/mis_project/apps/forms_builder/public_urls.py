from django.urls import path
from .views import PublicFormView

urlpatterns = [
    path("<uuid:token>/", PublicFormView.as_view(), name="public_form"),
]
